baseRepoURI="http://localhost:7200/repositories/Base"
tempRepoURI="http://localhost:7200/repositories/Temp"